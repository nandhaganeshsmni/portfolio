package incrementorpackage;
import incremen.*;

public class Incrementor2{

	public static void main(String[] args) {
		Incrementor inc=new Incrementor();
		int[] b={4,6,9,1,3};
		inc.getNum(b);
	}
}