package sumspackage;

import sumpackage.*;

public class Sums{

	public static void main(String[] args) {
		Sum sum=new Sum();
		int[] a={1,2,3,4,5};
		int b=6;
		sum.getSum(a,b);
	}
}